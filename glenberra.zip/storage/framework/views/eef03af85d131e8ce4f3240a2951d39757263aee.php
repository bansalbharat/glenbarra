


<?php $__env->startSection('css'); ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('content-header'); ?>

    Events & Exhibitions

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

<div class="card">
              <div class="card-header">
                <h3 class="card-title">View Events & Exhibitions</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table class="table table-bordered">
                  <thead>
                    <tr>
                      <th>Display Order</th>
                      <th>Year</th>
                      <th>Title</th>
                      <th>Sub-title</th>
                      <th>Supported/Presented By</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>1.</td>
                      <td>02/07/2020</td>
                      <td>Mumbai Mirror</td>
                      <td>Paintings of his dreams</td>
                      <td>Narseen</td>
                      <td class="text-center">
                          <i class="fas fa-edit"></i><br>
                          <i class="fas fa-trash-alt"></i>
                      </td>
                    </tr>
                    <tr>
                      <td>2.</td>
                      <td>02/07/2020</td>
                      <td>Mumbai Mirror</td>
                      <td>Paintings of his dreams</td>
                      <td>Narseen</td>
                      <td class="text-center">
                          <i class="fas fa-edit"></i><br>
                          <i class="fas fa-trash-alt"></i>
                      </td>
                    </tr>
                    <tr>
                      <td>3.</td>
                      <td>02/07/2020</td>
                      <td>Mumbai Mirror</td>
                      <td>Paintings of his dreams</td>
                      <td>Narseen</td>
                      <td class="text-center">
                          <i class="fas fa-edit"></i><br>
                          <i class="fas fa-trash-alt"></i>
                      </td>
                    </tr>
                    <tr>
                      <td>4.</td>
                      <td>02/07/2020</td>
                      <td>Mumbai Mirror</td>
                      <td>Paintings of his dreams</td>
                      <td>Narseen</td>
                      <td class="text-center">
                          <i class="fas fa-edit"></i><br>
                          <i class="fas fa-trash-alt"></i>
                      </td>
                    </tr>                    <tr>
                      <td>5.</td>
                      <td>02/07/2020</td>
                      <td>Mumbai Mirror</td>
                      <td>Paintings of his dreams</td>
                      <td>Narseen</td>
                      <td class="text-center">
                          <i class="fas fa-edit"></i><br>
                          <i class="fas fa-trash-alt"></i>
                      </td>
                    </tr>                    <tr>
                      <td>6.</td>
                      <td>02/07/2020</td>
                      <td>Mumbai Mirror</td>
                      <td>Paintings of his dreams</td>
                      <td>Narseen</td>
                      <td class="text-center">
                          <i class="fas fa-edit"></i><br>
                          <i class="fas fa-trash-alt"></i>
                      </td>
                    </tr>                    <tr>
                      <td>7.</td>
                      <td>02/07/2020</td>
                      <td>Mumbai Mirror</td>
                      <td>Paintings of his dreams</td>
                      <td>Narseen</td>
                      <td class="text-center">
                          <i class="fas fa-edit"></i><br>
                          <i class="fas fa-trash-alt"></i>
                      </td>
                    </tr>                    <tr>
                      <td>8.</td>
                      <td>02/07/2020</td>
                      <td>Mumbai Mirror</td>
                      <td>Paintings of his dreams</td>
                      <td>Narseen</td>
                      <td class="text-center">
                          <i class="fas fa-edit"></i><br>
                          <i class="fas fa-trash-alt"></i>
                      </td>
                    </tr>                    <tr>
                      <td>9.</td>
                      <td>02/07/2020</td>
                      <td>Mumbai Mirror</td>
                      <td>Paintings of his dreams</td>
                      <td>Narseen</td>
                      <td class="text-center">
                          <i class="fas fa-edit"></i><br>
                          <i class="fas fa-trash-alt"></i>
                      </td>
                    </tr>
                    
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->

</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Softwares\Installed\Xampp\htdocs\glenberra\resources\views/admin/event-exhibition/view.blade.php ENDPATH**/ ?>